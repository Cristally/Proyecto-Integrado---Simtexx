// backend/src/controllers/ot.controller.js

// --- DATOS SIMULADOS (TRL 4) ---
const OTs_MOCK = [
    { id: 1, nombre: "Mantenimiento Preventivo A", responsable: "Juan Perez", estado: "Pendiente", fechaInicio: "2023-11-01", fechaFin: "2023-11-05" },
    { id: 2, nombre: "Reparación Motor X", responsable: "Maria Gomez", estado: "Finalizada", fechaInicio: "2023-10-10", fechaFin: "2023-10-12" },
    { id: 3, nombre: "Instalación Sensor", responsable: "Juan Perez", estado: "En Proceso", fechaInicio: "2023-11-15", fechaFin: "2023-11-20" },
    { id: 4, nombre: "Revisión General", responsable: "Carlos Ruiz", estado: "Pendiente", fechaInicio: "2023-12-01", fechaFin: "2023-12-03" },
    { id: 5, nombre: "Calibración Equipos", responsable: "Pedro Lopez", estado: "En Proceso", fechaInicio: "2023-11-18", fechaFin: "2023-11-25" },
    { id: 6, nombre: "Inspección de Seguridad", responsable: "Juan Perez", estado: "Finalizada", fechaInicio: "2023-09-01", fechaFin: "2023-09-02" }
];

export const obtenerOTs = (req, res) => {
    try {
        // Simulamos la seguridad obteniendo datos de los headers
        const userRole = req.headers['role']; 
        const userName = req.headers['username']; 
        
        // Obtenemos los filtros de la URL
        const { estado, fechaInicio, fechaFin, busqueda } = req.query;

        let resultados = [...OTs_MOCK];

        // --- CRITERIO 4: Control de Acceso por Rol ---
        // Si el usuario NO es admin, solo ve sus propias OTs
        if (userRole !== 'admin') {
            resultados = resultados.filter(ot => ot.responsable === userName);
        }

        // --- CRITERIOS 2 y 3: Filtros Combinados ---

        // 1. Filtro por Estado
        if (estado && estado !== "Todos") {
            resultados = resultados.filter(ot => ot.estado === estado);
        }

        // 2. Filtro por Búsqueda (Texto en Nombre o Responsable)
        if (busqueda) {
            const termino = busqueda.toLowerCase();
            resultados = resultados.filter(ot => 
                ot.nombre.toLowerCase().includes(termino) || 
                ot.responsable.toLowerCase().includes(termino)
            );
        }

        // 3. Filtro por Fechas (Inicio y Fin de contrato)
        if (fechaInicio && fechaFin) {
            resultados = resultados.filter(ot => 
                new Date(ot.fechaInicio) >= new Date(fechaInicio) && 
                new Date(ot.fechaFin) <= new Date(fechaFin)
            );
        }

        // --- CRITERIO 5: Mensaje si no hay datos ---
        if (resultados.length === 0) {
            // Devolvemos array vacío pero con código 200
            return res.status(200).json({ data: [], mensaje: "No se encontraron OT con los filtros seleccionados." });
        }

        // --- CRITERIO 1: Retorno de datos ---
        res.status(200).json({ data: resultados });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error interno del servidor" });
    }
};